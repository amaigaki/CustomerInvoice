package com.seclore.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.seclore.dao.CustomerDAO;
import com.seclore.dao.InvoiceDAO;

@WebServlet("/NavigationServlet")
public class NavigationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String pageName = request.getParameter("rdoPage");
		String customerId = request.getParameter("txtCustomerId");
		PrintWriter out = response.getWriter();

		CustomerDAO customerdao = new CustomerDAO();
		InvoiceDAO invoicedao = new InvoiceDAO();

		if (pageName.equals("Customer")) {
			if (customerdao.getCustomerById(Integer.valueOf(customerId)) != null) {
				request.getRequestDispatcher("UpdateCustomer.jsp").forward(request, response);
			} else {
				response.sendRedirect("AddCustomer.jsp");
			}

		} else {
			String invoiceId = request.getParameter("txtInvoiceId");
			if (customerdao.getCustomerById(Integer.valueOf(customerId)) != null) {
				if (invoicedao.getInvoiceById(invoiceId) != null) {
					out.println("Invoice is present!");
				} else {
					out.println("Invoice is not present!");
				}
			} else {
				response.sendRedirect("AddCustomer.jsp");
			}
		}
	}

}
