package com.seclore.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.seclore.dao.CustomerDAO;
import com.seclore.pojo.Customer;

@WebServlet("/AddCustomerServlet")
public class AddCustomerServlet extends HttpServlet {
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		
		String customerName = request.getParameter("txtCustomerName");
		String customerType = request.getParameter("optCustomerType");
		boolean customerActive = request.getParameter("chkCustomerActive") != null;
		float customerCreditLimit = Float.valueOf(request.getParameter("txtCustomerCreditLimit"));
		
		Customer customer = new Customer(0,customerName,customerType,customerActive,customerCreditLimit);
		CustomerDAO dao = new CustomerDAO();
		
		if(dao.addCustomer(customer)) {
			out.println("Customer Added Successfully!");
			request.getRequestDispatcher("Index.jsp").include(request, response);
		}else {
			out.println("Failed to add customer!");
			request.getRequestDispatcher("AddCustomer.jsp").include(request, response);
		}
	}

}
