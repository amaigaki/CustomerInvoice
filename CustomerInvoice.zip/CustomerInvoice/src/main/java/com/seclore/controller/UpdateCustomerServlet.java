package com.seclore.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.seclore.dao.CustomerDAO;
import com.seclore.pojo.Customer;

@WebServlet("/UpdateCustomerServlet")
public class UpdateCustomerServlet extends HttpServlet {

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		
		int customerId = (int)request.getSession().getAttribute("txtCustomerId");
		String customerName = request.getParameter("txtCustomerName");
		String customerType = request.getParameter("optCustomerType");
		boolean customerActive = request.getParameter("chkCustomerActive") != null;
		float customerCreditLimit = Float.valueOf(request.getParameter("txtCustomerCreditLimit"));
		
		Customer customer = new Customer(customerId,customerName,customerType,customerActive,customerCreditLimit);
		CustomerDAO dao = new CustomerDAO();
		
		if(dao.updateCustomer(customer)) {
			out.println("Customer Updated Successfully!");
			request.getRequestDispatcher("Index.jsp").include(request, response);
		}else {
			out.println("Failed to update customer!");
			request.getRequestDispatcher("UpdateCustomer.jsp").include(request, response);
		}
	}

}
