package com.seclore.pojo;

public class Customer {
	private int customerId;
	private String customerName;
	private String customerType;
	private boolean customerActive;
	private float customerCreditLimit;
	
	public Customer() {
		super();
	}
	
	public Customer(int customerId, String customerName, String customerType, boolean customerActive,
			float customerCreditLimit) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.customerType = customerType;
		this.customerActive = customerActive;
		this.customerCreditLimit = customerCreditLimit;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getCustomerType() {
		return customerType;
	}

	public void setCustomerType(String customerType) {
		this.customerType = customerType;
	}

	public boolean getCustomerActive() {
		return customerActive;
	}

	public void setCustomerActive(boolean customerActive) {
		this.customerActive = customerActive;
	}

	public float getCustomerCreditLimit() {
		return customerCreditLimit;
	}

	public void setCustomerCreditLimit(float customerCreditLimit) {
		this.customerCreditLimit = customerCreditLimit;
	}

	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", customerName=" + customerName + ", customerType="
				+ customerType + ", customerActive=" + customerActive + ", customerCreditLimit=" + customerCreditLimit
				+ "]";
	}

}
