package com.seclore.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.seclore.factory.ConnectionFactory;
import com.seclore.pojo.Invoice;

public class InvoiceDAO {
	private Connection connection;
	private PreparedStatement preparedStatement;
	private ResultSet resultSet;
	private String sql;
	private int count;

	public Invoice getInvoiceById(String invoiceId) {
		try {
			connection = ConnectionFactory.getConnection();
			sql = "select * from invoice_details;";
			preparedStatement = connection.prepareStatement(sql);
			resultSet = preparedStatement.executeQuery();
			if (resultSet.next()) {
				Invoice invoice = new Invoice();
				CustomerDAO custDAO = new CustomerDAO();
				invoice.setInvoiceId(resultSet.getInt("invoice_id"));
				invoice.setInvoiceAmount(resultSet.getFloat("invoice_amount"));
				invoice.setInvoiceDate(resultSet.getDate("invoice_date"));
				invoice.setInvoiceStatus(resultSet.getInt("invoice_status"));
				invoice.setCustomer(custDAO.getCustomerById(Integer.valueOf(resultSet.getString("customer_id"))));
				invoice.setPaidDate(resultSet.getDate("paid_date"));
				invoice.setDueDate(resultSet.getDate("due_date"));
				return invoice;
			}

		} catch (ClassNotFoundException | SQLException e) {
			System.out.println(e.getMessage());
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				System.out.println(e.getMessage());
			}
		}
		return null;
	}

	public Boolean addInvoice(Invoice invoice) {
		try {
			connection = ConnectionFactory.getConnection();

			sql = "insert into customer_details values(?,?,?,?,?,?)";

			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setInt(1, invoice.getInvoiceId());
			preparedStatement.setFloat(2, invoice.getInvoiceAmount());
			preparedStatement.setDate(3, invoice.getInvoiceDate());
			preparedStatement.setInt(4, invoice.getInvoiceStatus());
			preparedStatement.setInt(5, invoice.getCustomer().getCustomerId());
			preparedStatement.setDate(6, invoice.getPaidDate());
			preparedStatement.setDate(7, invoice.getDueDate());

			count = preparedStatement.executeUpdate();

			if (count > 0)
				return true;
		} catch (ClassNotFoundException | SQLException e) {
			System.out.println(e.getMessage());
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				System.out.println(e.getMessage());
			}
		}
		return false;
	}

}