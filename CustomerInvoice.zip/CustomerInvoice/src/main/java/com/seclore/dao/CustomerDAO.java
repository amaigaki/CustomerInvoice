package com.seclore.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.seclore.factory.ConnectionFactory;
import com.seclore.pojo.Customer;

public class CustomerDAO {
	private Connection connection;
	private PreparedStatement preparedStatement;
	private ResultSet resultSet;
	private String sql;
	private int count;

	public Customer getCustomerById(int customerId) {
		try {
			connection = ConnectionFactory.getConnection();
			sql = "select * from customer_details where customer_id = ?;";
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setInt(1, customerId);
			resultSet = preparedStatement.executeQuery();
			if (resultSet.next()) {
				Customer customer = new Customer();
				customer.setCustomerId(resultSet.getInt("customer_id"));
				customer.setCustomerName(resultSet.getString("customer_name"));
				customer.setCustomerType(resultSet.getString("customer_type"));
				customer.setCustomerActive(resultSet.getBoolean("customer_active"));
				customer.setCustomerCreditLimit(resultSet.getFloat("customer_credit_limit"));
				return customer;
			}

		} catch (ClassNotFoundException | SQLException e) {
			System.out.println(e.getMessage());
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				System.out.println(e.getMessage());
			}
		}
		return null;
	}

	public Boolean addCustomer(Customer customer) {
		try {
			connection = ConnectionFactory.getConnection();

			sql = "insert into customer_details values(?,?,?,?)";

			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setString(1, customer.getCustomerName());
			preparedStatement.setString(2, customer.getCustomerType());
			preparedStatement.setBoolean(3, customer.getCustomerActive());
			preparedStatement.setFloat(4, customer.getCustomerCreditLimit());

			count = preparedStatement.executeUpdate();

			if (count > 0)
				return true;
		} catch (ClassNotFoundException | SQLException e) {
			System.out.println(e.getMessage());
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				System.out.println(e.getMessage());
			}
		}
		return false;
	}
	
	public Boolean updateCustomer(Customer customer) {
		try {
			connection = ConnectionFactory.getConnection();

			sql = "update customer_details set customer_name=?, customer_type=?, customer_active=?, customer_credit_limit=? where customer_id=?";

			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setString(1, customer.getCustomerName());
			preparedStatement.setString(2, customer.getCustomerType());
			preparedStatement.setBoolean(3, customer.getCustomerActive());
			preparedStatement.setFloat(4, customer.getCustomerCreditLimit());
			preparedStatement.setInt(5, customer.getCustomerId());

			count = preparedStatement.executeUpdate();

			if (count > 0)
				return true;
		} catch (ClassNotFoundException | SQLException e) {
			System.out.println(e.getMessage());
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				System.out.println(e.getMessage());
			}
		}
		return false;
	}
}
